package es.ucm.fdi.iw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IwApplication {

	public static void main(String[] args) {
		SpringApplication.run(IwApplication.class, args);
	}

}

